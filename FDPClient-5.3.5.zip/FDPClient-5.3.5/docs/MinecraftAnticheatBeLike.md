# 现在各种新反作弊be like:
CV开发大法  
EZ Bypass  
一生更新一次  
支持版本跨度非常史山  
问题比检测多  
绕过比问题多  
Checks-(A~Z)-(1~114514).property-(A-Z)-(1~114514).Type(A-Z)  
令人迷惑的配置文件和检测令名  
9.99USD 14.99USD 29.99USD 99.99USD  
宣传营销经费赶上赚的钱  
被纪狗上传社交平台疯狂拷打  
被免费的外纪狠狠暴打  
被原版LiquidBounce暴打  
被Impact暴打  
被Wurst暴打  
使用者不断拷打逼迫你更新  
总能在Paper TaskError  
时不时控制台给你蹦一个NPE  
错误！难道他已经更新了？  
更新：修复了0个问题  
再更新：新增了10个绕过  
再再更新：最后一次更新，跑路  
Disabler Disabler Disabler(BGM:Gas Gas Gas)  
Disabler Patched Fly Bypassed  
Fly Patched Disabler Bypassed  
Fly Patched Disabler Patched Teleport Bypassed  
误判+++++++++  
AntiLegitPlayer  
AllowBlatantCheater  
总能在莫名奇怪的地方被绕过  
总能在莫名其妙的地方误判  
在你向作者（Github）提交错误（绕过）后，在365天后维护成功  
在你向作者（Github）提交错误（绕过）后，在114514天后维护成功  
在你向作者（Github）提交错误（绕过）后，在NaN天后维护成功  
在你向作者（Github）提交错误（绕过）后，Not Important, Closed  
在你向作者（Github）提交错误（绕过）后，被踢出Discord服务器  
反编译一看——百家成分  
仔细看看——Reflection套Reflection  
再认真研究研究——屎山  
