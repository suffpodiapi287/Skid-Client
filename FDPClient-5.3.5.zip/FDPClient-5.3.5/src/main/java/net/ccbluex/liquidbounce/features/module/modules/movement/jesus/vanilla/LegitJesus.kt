package net.ccbluex.liquidbounce.features.module.modules.movement.jesus.vanilla

import net.ccbluex.liquidbounce.features.module.modules.movement.jesus.JesusMode

class LegitJesus : JesusMode("Legit") {
}